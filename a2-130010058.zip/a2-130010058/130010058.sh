python question1.py
python question2.py
python question3.py
pdflatex 130010058.tex
rm 130010058.aux
rm 130010058.log
rm *.png
okular 130010058.pdf
