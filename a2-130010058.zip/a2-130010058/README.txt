#Assignment 2
#Vikas Kurapati
#130010058

To run the assignment code. Please follow the below mentioned steps:
1. You need to have Python installed.
2. You'll need a pdflatex builder.
3. Following packages of latex are needed:
	i) authblk
	ii) etoolbox
	iii) lmodern
	iv) titlesex
	v) float
	vi) graphicx
4. You'll need okular reader to open the pdf.(In case, you don't have it, you can change the script slightly to incorporate your reader by replacing okular with your reader in the bash script)
5. Run 130010058.sh using command ./130010058.sh
6. In case, it gives any error saying any permission issues or access denied, run chmod ug+x 130010058.sh
7. Now run the command ./130010058.sh again.

Cheers!
