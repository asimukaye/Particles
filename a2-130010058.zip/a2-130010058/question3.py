#Assignment 2 Question 3
#Vikas Kurapati
#130010058

from matplotlib import pyplot as plt
import numpy as np
from numpy import linalg as LA

def vortex_velocity(z, vor, gamma):
	compl_vel = (-1j*gamma/(2*np.pi*(z - vor))).conjugate()
	return compl_vel

def test_vortex_velocity():
    z = complex(2.0, 1)
    z_vor = complex(1., 1.0)
    expect = 1j

    result = vortex_velocity(z, z_vor, np.pi*2)
    assert abs(result.imag - expect.imag) < 1e-14
    assert abs(result.real - expect.real) < 1e-14
    assert np.absolute(result - expect) < 1e-14


def vortex_velocities(pos, gamma):
	vel = np.zeros_like(pos)
	for i, z_i in enumerate(pos):
		for j, z_j in enumerate(pos):
			if i!= j:
				vel[i] = vel[i] + vortex_velocity(z_i,z_j,gamma[j])
	return vel

def test_vortex_velocities():
	vor_z = np.asarray([complex(0.5,0) , complex(-0.5,0)])
	gamma = np.asarray([2*np.pi , 2*np.pi])
	expect = [1j , -1j]

	result = vortex_velocities(vor_z,gamma)
	assert np.LA.norm(expect - result) < 1e-14

def euler(pos, gamma, dt, time):
	result = [pos]
	t = 0.
	while t < time:
		vel = vortex_velocities(pos,gamma)
		pos = pos + vel*dt
		result.append(pos.copy())
		t = t + dt
	return np.asarray(result)

def RK2(pos, gamma, dt, time):
	result = [pos]
	t = 0.
	while t < time:
		k1 = dt*vortex_velocities(pos,gamma)
		k2 = dt*vortex_velocities(pos+k1,gamma)
		pos = pos + 0.5*(k1 + k2)
		result.append(pos.copy())
		t = t + dt
	return np.asarray(result)

def problem3(vor_z, gamma, dt, time, method = 'euler'):
	if method == 'euler':
		result = euler(vor_z, gamma, dt, time)
	elif method == 'RK2':
		result = RK2(vor_z, gamma, dt, time)
	return result

def error_final_position(vor_z, vor_z_final, gamma, dt, time, method = 'euler'):
	if method == 'euler':
		result_euler = euler(vor_z, gamma, dt, time)
		vor_z_final_euler = result_euler[-1]
		error_pos = vor_z_final - vor_z_final_euler
		normalised_error_pos = error_pos/vor_z_final
		error = 0
		for i in normalised_error_pos:
			error = error + np.absolute(i)
		return error
	if method == 'RK2':
		result_RK2 = RK2(vor_z, gamma, dt, time)
		vor_z_final_RK2 = result_RK2[-1]
		error_pos = vor_z_final - vor_z_final_RK2
		normalised_error_pos = error_pos/vor_z_final
		error = 0
		for i in normalised_error_pos:
			error = error + np.absolute(i)
		return error

def convergence_final_position(vor_z, vor_z_final, gamma, time):
	ERR_EULER = []
	ERR_RK2 = []
	DT = []
	dt = 0.0001
	while dt < 0.003:
		ERR_EULER.append(error_final_position(vor_z, vor_z_final, gamma, dt, time, method = 'euler'))
		ERR_RK2.append(error_final_position(vor_z, vor_z_final, gamma, dt, time, method = 'RK2'))
		DT.append(dt)
		dt = dt + 0.0005
	return ERR_EULER, ERR_RK2, DT

'''
def exact_pos(vor_z, dt, time):
	t = 0.
	exact_pos = [vor_z]
	while t < time:
		t = t + dt
		new_pos = vor_z * np.exp(2j*t)
		exact_pos.append(new_pos)
	return np.asarray(exact_pos)

def error_sum(vor_z, gamma, dt, time, method = 'euler'):
	exact_sol = exact_pos(vor_z, dt, time)
	if method == 'euler':
		result_euler = euler(vor_z, gamma, dt, time)
		error_pos = exact_sol - result_euler
		normalised_error_pos = error_pos/exact_sol
		error = 0
		for j in range(2):
			for i in normalised_error_pos[:,j]:
				error = error + np.absolute(i)
		return error
	if method == 'RK2':
		result_RK2 = RK2(vor_z, gamma, dt, time)
		error_pos = exact_sol - result_RK2
		normalised_error_pos = error_pos/exact_sol
		error = 0
		for j in range(2):
			for i in normalised_error_pos[:,j]:
				error = error + np.absolute(i)
		return error

def convergence_sum(vor_z, gamma, time):
	ERR_EULER = []
	ERR_RK2 = []
	DT = []
	dt = 0.0001
	while dt < 0.003:
		ERR_EULER.append(error_sum(vor_z, gamma, dt, time, method = 'euler'))
		ERR_RK2.append(error_sum(vor_z, gamma, dt, time, method = 'RK2'))
		DT.append(dt)
		dt = dt + 0.0005
	return ERR_EULER, ERR_RK2, DT
'''

if __name__ == '__main__':
	vor_z = np.asarray([complex(0.5,0) , complex(-0.5,0)])
	vor_z_final = np.asarray([0.5*np.exp(10j) , -0.5*np.exp(10j)])
	gamma = np.asarray([2*np.pi , 2*np.pi])
	
	array = problem3(vor_z, gamma, 0.1, 5. ,'euler')
	x = array.real
	y = array.imag
	plt.figure(1)
	plt.plot(x, y)
	plt.title("Path of vortices in Euler's scheme with dt = 0.1")
	plt.savefig('Q3Eulerdtpoint1')
	array = problem3(vor_z, gamma, 0.01, 5. ,'euler')
	x = array.real
	y = array.imag
	plt.figure(2)
	plt.plot(x, y)
	plt.title("Path of vortices in Euler's scheme with dt = 0.01")
	plt.savefig('Q3Eulerdtpoint01')
	array = problem3(vor_z, gamma, 0.1, 5. ,'RK2')
	x = array.real
	y = array.imag
	plt.figure(3)
	plt.plot(x, y)
	plt.title("Path of vortices in RK2 scheme with dt = 0.1")
	plt.savefig('Q3RK2dtpoint1')
	array = problem3(vor_z, gamma, 0.01, 5. ,'RK2')
	x = array.real
	y = array.imag
	plt.figure(4)
	plt.plot(x, y)
	plt.title("Path of vortices in RK2 scheme with dt = 0.01")
	plt.savefig('Q3RK2dtpoint01')
	
	ERR_EULER, ERR_RK2, DT = convergence_final_position(vor_z, vor_z_final, gamma, 5.)
	plt.figure(5)
	plt.loglog(DT,ERR_EULER,label='Euler')
	plt.loglog(DT,ERR_RK2,label='RK2')
	plt.xlabel('Log of Time Step')
	plt.ylabel('Log of Error based on Final Position')
	plt.legend(loc = 'lower right')
	plt.savefig('Q3Convergencefinalpos')
	
	'''
	ERR_EULER, ERR_RK2, DT = convergence_sum(vor_z, gamma, 5.)
	plt.figure(5)
	plt.loglog(DT,ERR_EULER,label='Euler')
	plt.loglog(DT,ERR_RK2,label='RK2')
	plt.xlabel('Log of Time Step')
	plt.ylabel('Log of Error based on sum of positions at different time steps')
	plt.legend(loc = 'lower right')
	plt.savefig('Q3Convergencesumpos')
	'''