#Assignment 3
#Vikas Kurapati
#130010058 

import numpy as np
from matplotlib import pyplot as plt
import copy

plot_count = 1
def vortex_velocity(z, vor, gamma):
	compl_vel = -1j*gamma/(2*np.pi*(z - vor))
	return compl_vel.conjugate()

def vortex_velocities(pos, gamma):
	vel = np.zeros_like(pos)
	for i, z_i in enumerate(pos):
		for j, z_j in enumerate(pos):
			if i!= j:
				vel[i] = vel[i] + vortex_velocity(z_i,z_j,gamma[j])
	return vel

def vortices_linspace(ymin,ymax,N=51):
	z = []
	y = np.linspace(ymin,ymax,N)
	pos = [complex(0,p) for p in y]
	gamma = np.zeros_like(pos)
	for i in range(len(pos) - 1):
		x = 0.5*(pos[i] + pos[i+1])
		z.append(x)
		strength = np.sqrt(1-4*y[i]*y[i])-np.sqrt(1-4*y[i+1]*y[i+1])
		gamma[i] = strength.copy()
	return z, gamma

def vortices_sinspace(b,N=51):
	theta = np.linspace(-0.5*np.pi,0.5*np.pi,N)
	pos = 0.5*np.sin(theta)*b
	complex_pos = [complex(0,p) for p in pos]
	z = np.zeros_like(complex_pos)
	gamma = np.zeros_like(complex_pos)
	for i in range(len(complex_pos) - 1):
		x = 0.5*(complex_pos[i] + complex_pos[i+1])
		z[i] = copy.copy(x)
		strength = np.sqrt(1-4*pos[i]*pos[i])-np.sqrt(1-4*pos[i+1]*pos[i+1])
		gamma[i] = strength.copy()
	return z,gamma
	
def RK2(pos, gamma, dt, time):
	result = [pos]
	t = 0.
	while t < time:
		k1 = dt*vortex_velocities(pos,gamma)
		k2 = dt*vortex_velocities(pos+k1,gamma)
		pos = pos + 0.5*(k1 + k2)
		result.append(pos.copy())
		t = t + dt
	return np.asarray(result)

def RK2_blob(pos, gamma, dt, time,delta):
	result = [pos]
	t = 0.
	while t < time:
		k1 = dt*blob_vel(pos,gamma,delta)
		k2 = dt*blob_vel(pos+k1,gamma,delta)
		pos = pos + 0.5*(k1 + k2)
		result.append(pos.copy())
		t = t + dt
	return np.asarray(result)
 
def problem1_linspace(ymin,ymax,t,dt,N=51):
	global plot_count
	pos,gamma = vortices_linspace(ymin,ymax,N)
	result = RK2(pos,gamma,dt,t)
	final_result = result[-1]
	final_x = final_result.real
	final_y = final_result.imag
	plt.plot(final_x,final_y,'*')
	plt.title('At t=' + str(t) + ' with dt=' + str(dt)+' with'+str(N)+ 'point vortices discretization')
	plt.savefig(str(plot_count)+'.png')
	plot_count = plot_count + 1
	plt. close()
	return final_x,final_y

def problem1_sinspace(b,t,dt,N=51):
	global plot_count
	pos,gamma = vortices_sinspace(b,N)
	result = RK2(pos,gamma,dt,t)
	final_result = result[-1]
	final_x = final_result.real
	final_y = final_result.imag
	plt.plot(final_x,final_y,'+')
	plt.title('At t=' + str(t) + ' with dt=' + str(dt)+' with'+str(N)+' point vortices discretization')
	plt.savefig(str(plot_count)+'.png')
	plot_count = plot_count + 1
	plt.close()
	return final_x,final_y
    
def problem1(b,ymin,ymax,t,dt,N=51):
	global plot_count
	x_l,y_l = problem1_linspace(ymin,ymax,t,dt,N)
	x_s,y_s = problem1_sinspace(b,t,dt,N)
	plt.plot(x_l,y_l,'*',label = 'linspace distrubuted')
	plt.plot(x_s,y_s,'+',label = 'sinspace distributed')
	plt.legend(loc = 3)
	plt.title('At t=' + str(t) + ' with dt=' + str(dt)+' with'+str(N) +'point vortices discretization')
	plt.savefig(str(plot_count)+'.png')
	plot_count = plot_count + 1
	plt.close()
 
def blob_vel(pos,gamma,delta):
	vel = np.zeros_like(pos)
	for i, z_i in enumerate(pos):
		for j, z_j in enumerate(pos):
			vel[i] = vel[i] + 1j*gamma[j]*(z_i - z_j)/(2*np.pi*(abs((z_i-z_j)**2) + delta**2))
	return vel

def problem2_linspace(ymin,ymax,t,dt,N=51,delta_factor=0.55):
	global plot_count
	pos,gamma = vortices_linspace(ymin,ymax,N)
	delta = delta_factor*(ymax - ymin)/(N-1)
	result = RK2_blob(pos,gamma,dt,t,delta)
	final_result = result[-1]
	final_x = final_result.real
	final_y = final_result.imag
	plt.plot(final_x,final_y,'*')
	plt.title('At t=' + str(t) + ' with dt=' + str(dt)+' with'+str(N)+'blobs'+str(delta_factor)+' delta factor')
	plt.savefig(str(plot_count)+'.png')
	plot_count = plot_count + 1
	plt.close()	
	return final_x,final_y

def problem2_sinspace(b,t,dt,N=51,delta_factor=0.55):
	global plot_count
	pos,gamma = vortices_sinspace(b,N)
	delta = delta_factor*b/(N - 1)
	result = RK2_blob(pos,gamma,dt,t,delta)
	final_result = result[-1]
	final_x = final_result.real
	final_y = final_result.imag
	plt.plot(final_x,final_y,'+')
	plt.title('At t=' + str(t) + ' with dt=' + str(dt)+' with'+str(N)+'blobs'+str(delta_factor)+' delta factor')
	plt.savefig(str(plot_count)+'.png')
	plot_count = plot_count + 1
	plt.close()
	return final_x,final_y
    
def problem2(b,ymin,ymax,t,dt,N=51,delta_factor=0.55):
	global plot_count
	x_l,y_l = problem2_linspace(ymin,ymax,t,dt,N,delta_factor)
	x_s,y_s = problem2_sinspace(b,t,dt,N,delta_factor)
	plt.plot(x_l,y_l,'*',label = 'linspace distrubuted')
	plt.plot(x_s,y_s,'+',label = 'sinspace distributed')
	plt.legend(loc = 3)
	plt.title('At t=' + str(t) + ' with dt=' + str(dt)+' with'+str(N)+'blobs'+str(delta_factor)+' delta factor')
	plt.savefig(str(plot_count)+'.png')
	plt.close()
	plot_count = plot_count + 1
 
if __name__ == '__main__':
	problem1(1,-0.5,0.5,0,0.1,101)
	problem1(1,-0.5,0.5,2.5,0.1,101)
	problem1(1,-0.5,0.5,0,0.1,201)
	problem1(1,-0.5,0.5,2.5,0.1,201)
	problem2(1,-0.5,0.5,2.5,0.1,101,0.4)
	problem2(1,-0.5,0.5,2.5,0.1,101,0.5)
	problem2(1,-0.5,0.5,2.5,0.1,101,0.55)
	problem2(1,-0.5,0.5,2.5,0.1,101,0.6)
	problem2(1,-0.5,0.5,2.5,0.1,101,0.7)
