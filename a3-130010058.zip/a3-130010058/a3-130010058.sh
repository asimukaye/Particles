#!/bin/bash

python a3-130010058.py
pdflatex a3-130010058.tex
rm *.png
rm a3-130010058.aux
rm a3-130010058.log
