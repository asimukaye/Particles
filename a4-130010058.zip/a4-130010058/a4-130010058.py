#Assignment 4
#Vikas Kurapati
#130010058

import numpy as np
from matplotlib import pyplot as plt
import copy
from numpy import linalg as LA
#from scipy import integrate
#import scipy.special as special3

def vortex_velocity(z, vor, gamma):
	compl_vel = -1j*gamma/(2*np.pi*(z - vor))
	return compl_vel.conjugate()

def source_velocity(z, source, strength):
	compl_vel = strength/(2*np.pi*(z - source))
	return compl_vel.conjugate()

def vortex_velocities(pos, gamma):
	vel = np.zeros_like(pos)
	for i, z_i in enumerate(pos):
		for j, z_j in enumerate(pos):
			if i!= j:
				vel[i] = vel[i] + vortex_velocity(z_i,z_j,gamma[j])
	return vel

class Panel:
	"""Panel that contains initial,final points, control point,length, angle and direction of normal"""
	def __init__(self, x1,y1,x2,y2):
		self.p1 = x1 + 1j*y1	#(x1,y1)
		self.p2 = x2 + 1j*y2	#(x2,y2)
		self.control_point = 0.5*(x1+x2) + 0.5j*(y1+y2)
		self.length = np.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1))
		self.angle = np.angle(self.p2 - self.p1)
		self.normal = np.cos(self.angle + (np.pi)/2) + 1j*np.sin(self.angle + (np.pi)/2)

def panelize(r,n):
	theta = np.linspace(0,2*np.pi,n,endpoint = False)
	complex_pos = r*np.exp(1j*theta)
	x_pos = complex_pos.real
	y_pos = complex_pos.imag
	panels_matrix = np.empty(n,dtype = object)
	for i in range(n):
		panels_matrix[i] = Panel(x_pos[i%n],y_pos[i%n],x_pos[(i+1)%n],y_pos[(i+1)%n])
	return panels_matrix

def computeA(r,n):
	panels_matrix = panelize(r,n)
	A = np.zeros([n+1,n],dtype = float)
	for i in range(n):
		for j in range(n):
			if i!=j:
				a_ij = 1j*np.log((panels_matrix[i].control_point - panels_matrix[j].p2)/(panels_matrix[i].control_point - panels_matrix[j].p1)).conjugate()*np.exp(1j*panels_matrix[j].angle)/(2*np.pi)
				A[i][j] = (a_ij*panels_matrix[i].normal.conjugate()).real
	A[n][:] = 1.
	return A

def computeB(r,n,v_b = 0. + 0.*1j,u_inf = 1. + 0.*1j,pos_source = [0+0.*1j],str_source =[0],pos_vor =[0+0.*1j],gamma_vor=[0]):
	panels_matrix = panelize(r,n)
	B = np.zeros([n+1,1],dtype = float)
	for i in range(n):
		v_bn = (v_b.conjugate()*panels_matrix[i].normal).real
		v_fs = (u_inf.conjugate()*panels_matrix[i].normal).real
		v_s = 0 + 0j
		v_w = 0 + 0j
		for j, z_j in enumerate(pos_source):
			v_s += source_velocity(panels_matrix[i].control_point, z_j, str_source[j])
		v_s = (v_s.conjugate()*panels_matrix[i].normal).real
		for j,z_j in enumerate(pos_vor):
			v_w += vortex_velocity(panels_matrix[i].control_point, pos_vor[j], gamma_vor[j])
		v_w = (v_w.conjugate()*panels_matrix[i].normal).real
		B[i] = v_bn - v_fs - v_s - v_w
	return B

def computegamma(r,n,v_b = 0. + 0.*1j,u_inf = 1. + 0.*1j,pos_source = [0+0.*1j],str_source =[0],pos_vor =[0+0.*1j],gamma_vor=[0]):
	return LA.lstsq(computeA(r,n),computeB(r,n,v_b,u_inf,pos_source,str_source,pos_vor,gamma_vor))[0]

def vel_actual(u_inf=1.,R=1.,r=1.5,n=200):
	theta = np.linspace(0, 2*np.pi, n,endpoint = False)
	v_radial = u_inf*(1 - (R/r)*(R/r))*np.cos(theta)
	v_theta = -u_inf*(1 + (R/r)*(R/r))*np.sin(theta)
	v = np.sqrt(v_radial*v_radial + v_theta*v_theta)
	return np.asarray(v)

def vel_panel(u_inf=1.+0j,R=1.,r=1.5,n=200,N=20):
	theta = np.linspace(0, 2*np.pi, n, endpoint = False)
	pos = r*np.exp(1j*theta)
	A = computeA(R,N)
	B = computeB(R,N,0. + 0.*1j,u_inf,[0+0.*1j],[0],[0+0.*1j],[0])
	gamma = LA.lstsq(A,B)[0]
	vel = np.zeros(n) + 1.0j*np.zeros(n)
	panels = panelize(R,N)	
	for i,panel in enumerate(panels):
		z_new = (pos - panel.p1)*np.exp(-1.0j*panel.angle)
		v = ((-1.0j*gamma[i]*np.log((z_new - panel.length)/z_new)/(2*np.pi)).conjugate())*np.exp(1.0j*panel.angle)
		vel = vel + v
	vel = abs(np.array(vel)+u_inf)
	return vel

def error_plots(N):
	r = [1.1,1.5,2.,2.5,3.,3.5,5.,7.5,10.]
	Err = np.zeros(len(r))
	for i,n in enumerate(r):
		err = vel_panel(1.,1.,n,200,N) - vel_actual(1.,1.,n,200)
		sum_sqrs = 0
		for j in range(len(err)):
			sum_sqrs = sum_sqrs + abs(err[j])
		sum_sqrs = sum_sqrs/len(err)
		Err[i] = sum_sqrs
	plt.plot(r,Err)
	plt.title('Error vs radius where error is calculated for number of panels = '+str(N))
	plt.xlabel('r/R')
	plt.ylabel('Absolute Error')
	plt.savefig('q1_2n'+str(N)+'.png')
	plt.close()

def q1_2():
	for N in [20,30,40,50,75,100,125,150]:
		error_plots(N)

def problem3_panel(n = 50,r = 1.,  dt = 0.1, tf = 30.0, pos_vor = [1.5+0.*1j], gamma_m = [2*np.pi]):
	t = 0.
	pos = copy.copy(pos_vor)
	pos_matrix = [pos_vor]
	A = computeA(r,n)
	panels = panelize(r,n)
	while t<tf:
		B = computeB(r,n,0. + 0.*1j,0. + 0.0*1j,[0+0.*1j],[0.],pos,gamma_m)  #The error was I passed pos_vor where as I had to pass pos as argument for ComputeB.
		gamma = LA.lstsq(A,B)[0]
		v = 0. +0.0j
		for i,strength in enumerate(gamma):
			pos_r = (pos - panels[i].p1)*np.exp(-1.0j*panels[i].angle)
			v_iter = -1.0j*strength*np.log((pos_r - panels[i].length)/pos_r)/(2.0*np.pi)
			v = v + ((v_iter.conjugate())*np.exp(1.0j*panels[i].angle))		
		midpos = pos + v*dt/2.0
		midv = 0. +0.0j
		B = computeB(r,n,0. + 0.*1j,0. + 0.0*1j,[0+0.*1j],[0.],midpos,gamma_m)
		gamma = LA.lstsq(A,B)[0]
		for i,strength in enumerate(gamma):
			midpos_r = (midpos - panels[i].p1)*np.exp(-1.0j*panels[i].angle)
			midv_iter = -1.0j*strength*np.log((midpos_r - panels[i].length)/midpos_r)/(2.0*np.pi)
			midv = midv + ((midv_iter.conjugate())*np.exp(1.0j*panels[i].angle))
		pos = pos + midv*dt
		pos_matrix.append(copy.copy(pos))
		t = t+dt

	pos_matrix = np.asarray(pos_matrix)
	plt.plot(pos_matrix.real,pos_matrix.imag,label = 'Vortex Path')
	x=[]
	y=[]
	for panel in panels:
		x.append(panel.p1.real)
		y.append(panel.p1.imag)
	x.append(panels[0].p1.real)
	y.append(panels[0].p1.imag)
	plt.plot(x,y,label = 'Panels')
	plt.title('Path of vortex simulated using '+str(n)+' Panels')
	plt.legend()
	plt.savefig('q3paneln'+str(n)+'.png')	
	plt.close()
	return pos_matrix

def problem3_MOI(r = 1.,pos = 1.5 + 0.0j, gamma = 2*np.pi , dt = 0.1 ,tf = 30.0):
	vor_pos = [pos]
	t = 0.
	while t<tf:
		imag1 = r*r/(pos.conjugate())
		imag2 = 0 + 0j
		v = vortex_velocity(pos,imag1,-gamma) + vortex_velocity(pos,imag2,gamma)
		midpos = pos + v*dt/2.
		imag1 = r*r/(midpos.conjugate())
		v = vortex_velocity(midpos,imag1,-gamma) + vortex_velocity(midpos,imag2,gamma)
		pos = pos + v*dt
		vor_pos.append(copy.copy(pos))
		t = t+dt
	vor_post = np.asarray(vor_pos)
	theta = np.linspace(0,2*np.pi,200)
	x = r*np.cos(theta)
	y = r*np.sin(theta)
	plt.plot(vor_post.real,vor_post.imag,label = 'Vortex Path')
	plt.plot(x,y, label = 'Cylinder')
	plt.legend()
	plt.title('Path of vortex simulated using MOI')
	plt.savefig('q3MOI.png')
	plt.close()
	return vor_post

def problem3():
	Err = []
	N = [10,20,30,40,50,75,100]
	MOI_matrix = problem3_MOI(r = 1.,pos = 1.5 + 0.*1j,gamma = 2*np.pi,dt = 0.1 ,tf = 30.0)
	for n in N:
		panel_matrix = problem3_panel(n,r = 1., dt = 0.1, tf = 30.0, pos_vor = [1.5+0.*1j], gamma_m = [2*np.pi])
		Err.append(abs((sum(panel_matrix) - sum(MOI_matrix))/len(MOI_matrix)))#/sum(panel_matrix)))
	plt.plot(N,Err)
	plt.title('Error plot for vortex motion around a cylinder')
	plt.xlabel('Number of Panels')
	plt.ylabel('Error in calculation')
	plt.savefig('Q3Error.png')
	plt.close()

if __name__ == '__main__':
	q1_2()
	problem3()