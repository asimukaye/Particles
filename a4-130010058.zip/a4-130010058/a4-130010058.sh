#!/bin/bash

python a4-130010058.py
pdflatex a4-130010058.tex
pdflatex a4-130010058.tex
rm *.png
rm a4-130010058.aux
rm a4-130010058.log
