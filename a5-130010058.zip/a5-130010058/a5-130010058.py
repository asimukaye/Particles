#Assignment 5
#Vikas Kurapati
#130010058

import numpy as np
from matplotlib import pyplot as plt
import copy
from numpy import linalg as LA

def vortex_velocity(z, vor, gamma):
	compl_vel = -1j*gamma/(2*np.pi*(z - vor))
	return compl_vel.conjugate()

def source_velocity(z, source, strength):
	compl_vel = strength/(2*np.pi*(z - source))
	return compl_vel.conjugate()

def panel_vel(z,gamma1,gamma2,l):
	vel_gamma1 = (-1.0j*gamma1*(1. + (z/l - 1.)*np.log(1. - l/z))/(2.*np.pi)).conjugate()
	vel_gamma2 = (1.0j*gamma2*(1. + (z/l)*np.log(1. - l/z))/(2.0*np.pi)).conjugate()
	return vel_gamma1+vel_gamma2

class Panel:
	"""Panel with initial,final,control points, length and angle subtends"""
	def __init__(self,p1,p2):
		self.p1 = p1
		self.p2 = p2
		self.length = abs(p1 - p2)
		self.control_point = .5*(p1+p2)
		self.angle = np.angle(p2 - p1)
		self.normal = np.exp(1.0j*(self.angle + (np.pi/2.)))

def panelize(r,n):
	theta = np.linspace(0,2*np.pi,n,endpoint = False)
	complex_pos = r*np.exp(1j*theta)
	panels_matrix = np.empty(n,dtype = object)
	for i in range(n):
		panels_matrix[i] = Panel(complex_pos[i%n],complex_pos[(i+1)%n])
	return panels_matrix

def computeA(r=1.,n=20):
	panels_matrix = panelize(r,n)
	A = np.zeros([n+1,n],dtype = float)
	for i in range(n):
		for j in range(n):
			cp1_new = (panels_matrix[i%n].control_point - panels_matrix[j%n].p1)*np.exp(-1.0j*panels_matrix[j%n].angle)
			v_1 = -1.0j*(1. + (cp1_new/panels_matrix[j%n].length - 1.)*np.log(1. - panels_matrix[j%n].length/cp1_new))/(2.*np.pi)
			cp2_new = (panels_matrix[i%n].control_point - panels_matrix[(j-1)%n].p1)*np.exp(-1.0j*panels_matrix[(j-1)%n].angle)
			v_2 = 1.0j*(1. + (cp2_new/panels_matrix[(j-1)%n].length)*np.log(1. - panels_matrix[(j-1)%n].length/cp2_new))/(2.0*np.pi)
			v = v_1.conjugate()*np.exp(1.0j*panels_matrix[j%n].angle) + v_2.conjugate()*np.exp(1.0j*panels_matrix[(j-1)%n].angle)
			A[i][j] = (v.conjugate()*panels_matrix[i].normal).real
	A[n][:] = 1.
	return A

def computeB(r,n,v_b = 0. + 0.*1j,u_inf = 1. + 0.*1j,pos_source = [0+0.*1j],str_source =[0],pos_vor =[0+0.*1j],gamma_vor=[0]):
	panels_matrix = panelize(r,n)
	B = np.zeros([n+1,1],dtype = float)
	for i in range(n):
		v_bn = (v_b.conjugate()*panels_matrix[i].normal).real
		v_fs = (u_inf.conjugate()*panels_matrix[i].normal).real
		v_s = 0 + 0j
		v_w = 0 + 0j
		for j, z_j in enumerate(pos_source):
			v_s += source_velocity(panels_matrix[i].control_point, z_j, str_source[j])
		v_s = (v_s.conjugate()*panels_matrix[i].normal).real
		for j,z_j in enumerate(pos_vor):
			v_w += vortex_velocity(panels_matrix[i].control_point, pos_vor[j], gamma_vor[j])
		v_w = (v_w.conjugate()*panels_matrix[i].normal).real
		B[i] = v_bn - v_fs - v_s - v_w
	return B

def computegamma(r,n,v_b = 0. + 0.*1j,u_inf = 1. + 0.*1j,pos_source = [0+0.*1j],str_source =[0],pos_vor =[0+0.*1j],gamma_vor=[0]):
	return LA.lstsq(computeA(r,n),computeB(r,n,v_b,u_inf,pos_source,str_source,pos_vor,gamma_vor))[0]

def vel_actual(u_inf=1.,R=1.,r=1.5,n=200):
	theta = np.linspace(0, 2*np.pi, n,endpoint = False)
	v_radial = u_inf*(1 - (R/r)*(R/r))*np.cos(theta)
	v_theta = -u_inf*(1 + (R/r)*(R/r))*np.sin(theta)
	v = np.sqrt(v_radial*v_radial + v_theta*v_theta)
	return np.asarray(v)

def vel_panel(u_inf=1.+0j,R=1.,r=1.5,n=200,N=20):
	theta = np.linspace(0, 2*np.pi, n, endpoint = False)
	pos = r*np.exp(1j*theta)
	A = computeA(R,N)
	B = computeB(R,N,0. + 0.*1j,u_inf,[0+0.*1j],[0],[0+0.*1j],[0])
	gamma = LA.lstsq(A,B)[0]
	vel = np.zeros(n) + 1.0j*np.zeros(n)
	panels = panelize(R,N)	
	for i,panel in enumerate(panels):
		z_new = (pos - panel.p1)*np.exp(-1.0j*panel.angle)
		v = panel_vel(z_new, gamma[i%N], gamma[(i+1)%N], panel.length)*np.exp(1.0j*panel.angle)
		vel = vel + v
	vel = abs(np.array(vel)+u_inf)
	return vel

def error_plots(N):
	r = [1.1,1.5,2.,2.5,3.,3.5,5.,7.5,10.]
	Err = np.zeros(len(r))
	for i,n in enumerate(r):
		err = vel_panel(1.,1.,n,200,N) - vel_actual(1.,1.,n,200)
		sum_sqrs = 0
		for j in range(len(err)):
			sum_sqrs = sum_sqrs + abs(err[j])
		sum_sqrs = sum_sqrs/len(err)
		Err[i] = sum_sqrs
	plt.plot(r,Err)
	plt.title('Error vs radius where error is calculated for number of panels = '+str(N))
	plt.xlabel('r/R')
	plt.ylabel('Absolute Error')
	plt.savefig('q1_2n'+str(N)+'.png')
	plt.close()

def q1_2():
	for N in [20,30,40,50,75,100,125,150]:
		error_plots(N)

def problem3_MOI(r = 1.,pos = 1.5 + 0.0j, gamma = 2*np.pi , dt = 0.1 ,tf = 30.0):
	vor_pos = [pos]
	t = 0.
	while t<tf:
		imag1 = r*r/(pos.conjugate())
		imag2 = 0 + 0j
		v = vortex_velocity(pos,imag1,-gamma) + vortex_velocity(pos,imag2,gamma)
		midpos = pos + v*dt/2.
		imag1 = r*r/(midpos.conjugate())
		v = vortex_velocity(midpos,imag1,-gamma) + vortex_velocity(midpos,imag2,gamma)
		pos = pos + v*dt
		vor_pos.append(copy.copy(pos))
		t = t+dt
	vor_post = np.asarray(vor_pos)
	theta = np.linspace(0,2*np.pi,200)
	x = r*np.cos(theta)
	y = r*np.sin(theta)
	plt.plot(vor_post.real,vor_post.imag,label = 'Vortex Path')
	plt.plot(x,y, label = 'Cylinder')
	plt.legend()
	plt.title('Path of vortex simulated using MOI')
	plt.savefig('q3MOI.png')
	plt.close()
	return vor_post

def problem3_panel(n = 50,r = 1.,  dt = 0.1, tf = 30.0, pos_vor = [1.5+0.*1j], gamma_m = [2*np.pi]):
	t = 0.
	pos = copy.copy(pos_vor)
	pos_matrix = [pos_vor]
	A = computeA(r,n)
	panels = panelize(r,n)
	while t<tf:
		B = computeB(r,n,0. + 0.*1j,0. + 0.0*1j,[0+0.*1j],[0.],pos,gamma_m)
		gamma = LA.lstsq(A,B)[0]
		v = 0. +0.0j
		for i,panel in enumerate(panels):
			pos_r = (pos - panel.p1)*np.exp(-1.0j*panel.angle)
			vel = panel_vel(pos_r,gamma[i%n],gamma[(i+1)%n],panel.length)
			v = v + vel*np.exp(1.0j*panel.angle)
		midpos = pos + v*dt/2.
		midv = 0. + 0.0j
		B = computeB(r,n,0. + 0.*1j,0. + 0.0*1j,[0+0.*1j],[0.],midpos,gamma_m)
		gamma = LA.lstsq(A,B)[0]
		for i,panel in enumerate(panels):
			midpos_r = (midpos - panel.p1)*np.exp(-1.0j*panel.angle)
			midvel = panel_vel(midpos_r,gamma[i%n],gamma[(i+1)%n],panel.length)
			midv = midv + midvel*np.exp(1.0j*panel.angle)
		pos = pos + midv*dt
		pos_matrix.append(copy.copy(pos))
		t = t+dt
	pos_matrix = np.asarray(pos_matrix)
	plt.plot(pos_matrix.real,pos_matrix.imag,label = 'Vortex Path')
	x=[]
	y=[]
	for panel in panels:
		x.append(panel.p1.real)
		y.append(panel.p1.imag)
	x.append(panels[0].p1.real)
	y.append(panels[0].p1.imag)
	plt.plot(x,y,label = 'Panels')
	plt.title('Path of vortex simulated using '+str(n)+' Panels')
	plt.legend()
	plt.savefig('q3paneln'+str(n)+'.png')	
	plt.close()
	return pos_matrix

def problem3():
	Err = []
	N = [10,20,30,40,50,75,100]
	MOI_matrix = problem3_MOI(r = 1.,pos = 1.5 + 0.*1j,gamma = 2*np.pi,dt = 0.1 ,tf = 30.0)
	for n in N:
		panel_matrix = problem3_panel(n,r = 1., dt = 0.1, tf = 30.0, pos_vor = [1.5+0.*1j], gamma_m = [2*np.pi])
		Err.append(abs((sum(panel_matrix) - sum(MOI_matrix))/len(panel_matrix)))#/sum(panel_matrix)))
	plt.plot(N,Err)
	plt.title('Error plot for vortex motion around a cylinder')
	plt.xlabel('Number of Panels')
	plt.ylabel('Error in calculation')
	plt.savefig('Q3Error.png')
	plt.close()

if __name__ == '__main__':
	q1_2()
	problem3()