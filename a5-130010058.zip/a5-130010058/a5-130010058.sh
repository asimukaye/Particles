#!/bin/bash

python a5-130010058.py
pdflatex a5-130010058.tex
pdflatex a5-130010058.tex
rm *.png
rm a5-130010058.aux
rm a5-130010058.log
