#Assignment 6
#Vikas Kurapati
#130010058

import numpy as np
from matplotlib import pyplot as plt
import copy

class Particle:
	"""docstring for Particle"""
	def __init__(self,z1,z2,z3,z4,pos):
		self.z1 = z1
		self.z2 = z2
		self.z3 = z3
		self.z4 = z4
		self.pos = pos
		
def diffusion(n,nu,tf):		#n number of vortices are already placed at the center.
	"""This returns the final position of n vortices placed at origin each with a strength of gamma/n"""
	x = np.random.normal(0,np.sqrt(2*nu*tf),n) + 1.0j*np.random.normal(0,np.sqrt(2*nu*tf),n)
	return x

def remeshing(n,nu,tf,h,gamma):
	x= diffusion(n,nu,tf)
	X,Y = np.mgrid[-2.:2.:complex(0,4.0/h),-2.:2.:complex(0,4.0/h)]
	Z = np.ravel(X + 1.0j*Y)
	particles = np.empty(n,dtype = object)
	
	for k,particle in enumerate(x):
		i = int((particle.real+2.)/h)
		j = int((particle.imag+2.)/h)
		z1 = (-2. + i*h) + 1.0j*(-2.+ j*h)
		z2 = z1 + h
		z3 = z1 + 1j*h
		z4 = z3 + h
		particles[k] = Particle(z1,z2,z3,z4,particle)
	
	gamma_dict = {}
	for particle in particles:
		x = particle.pos.real - particle.z1.real
		y = particle.pos.imag - particle.z1.imag
		gamma_dict[particle.z1] = gamma_dict.get(particle.z1, 0.0) + gamma*(h-x)*(h-y)/n 
		gamma_dict[particle.z2] = gamma_dict.get(particle.z2, 0.0) + gamma*(x)*(h-y)/n	  
		gamma_dict[particle.z3] = gamma_dict.get(particle.z3, 0.0) + gamma*(h-x)*(y)/n   
		gamma_dict[particle.z4] = gamma_dict.get(particle.z4, 0.0) + gamma*(x)*(y)/n 	  
	z = np.array(gamma_dict.keys())
	rvm_gamma = np.array(gamma_dict.values())
	exact_gamma = gamma*h*h*np.exp(-np.absolute(z)*np.absolute(z)/(4*nu*tf))/(4*np.pi*nu*tf)
	error = sum(abs(rvm_gamma - exact_gamma))/len(exact_gamma)
	return error

def q():
	for i in range(10):
		Err = []
		N = [25,50,100,200,300,400,500]
		for n in N:
			Err.append(remeshing(n,0.1,1.0,0.05,1.0))
		plt.plot(N,Err)
		plt.title('Error in test case'+ str(i))
		plt.savefig('final'+str(i)+'.png')
		plt.close()

if __name__ == '__main__':
	q()