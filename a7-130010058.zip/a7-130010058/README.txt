#Assignment 7
#Vikas Kurapati
#130010058

To run the assignment code. Please follow the below mentioned steps:
1. You need to have Python installed.
2. You'll need a pdflatex builder.
3. Following packages of latex are needed:
	i) authblk
	ii) etoolbox
	iii) lmodern
	iv) titlesex
	v) float
	vi) graphicx
4 Run a7-130010058.sh using command ./a7-130010058.sh
5 In case, it gives any error saying any permission issues or access denied, run chmod ug+x a6-130010058.sh
6 Now run the command ./a7-130010058.sh again.

Cheers!
