#!/bin/bash

python a7-130010058.py
pdflatex a7-130010058.tex
pdflatex a7-130010058.tex
rm *.png
rm a7-130010058.aux
rm a7-130010058.log
