#Assignment 8
#Vikas Kurapati
#130010058

To run the assignment code. Please follow the below mentioned steps:
1. You need to have Python installed.
2. You need to have latest version of jupyter notebook to run the notebook and IPython.
3. Use a browser to open the html file in the output
4 Run make command by navigating to src folder and the output folder will be created with the images required, html file to be viewed.
5 Run make clean command in case you want to clean the output folder.

Cheers!
