cd ..
rm -rf output
cd src


